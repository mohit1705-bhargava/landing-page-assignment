// script.js

// 1. Enroll Now Button Click Alert
const enrollBtn = document.querySelector(".enroll-button");
if (enrollBtn) {
  enrollBtn.addEventListener("click", () => {
    alert(
      "🚀 You clicked Enroll! We'll guide you through the frontend journey."
    );
  });
}

// 2. Form Submit Event
const signupForm = document.getElementById("signup-form");
if (signupForm) {
  signupForm.addEventListener("submit", function (e) {
    e.preventDefault();
    const name = this.querySelector("input[type='text']").value;
    const email = this.querySelector("input[type='email']").value;
    alert(`Thanks for signing up, ${name}! We'll reach out to ${email} soon.`);
    this.reset();
  });
}

// 3. Call Button Click
const callButton = document.querySelector(".call-button2");
if (callButton) {
  callButton.addEventListener("click", () => {
    alert("📞 We'll contact you shortly for a free call!");
  });
}
// Check if there's a stored name and email, and if so, populate the form
window.onload = function () {
  const storedName = localStorage.getItem("userName");
  const storedEmail = localStorage.getItem("userEmail");

  if (storedName) {
    document.getElementById("user-name").value = storedName;
  }

  if (storedEmail) {
    document.getElementById("user-email").value = storedEmail;
  }
};

// Save name and email to localStorage when the form is submitted
// (for when user return to website to they not to entre there deatil website autmatically suggested there email and name)

document
  .getElementById("signup-form")
  .addEventListener("submit", function (event) {
    event.preventDefault(); // Prevent the form from submitting normally

    const userName = document.getElementById("user-name").value;
    const userEmail = document.getElementById("user-email").value;

    // Store the name and email in localStorage
    localStorage.setItem("userName", userName);
    localStorage.setItem("userEmail", userEmail);

    // You can add any additional logic for the form submission here (e.g., sending to a server)

    alert("Thank you for signing up!");
  });
